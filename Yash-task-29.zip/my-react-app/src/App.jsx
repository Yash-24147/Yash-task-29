
import { Link, Routes, Route } from "react-router-dom";
import { useCart } from "./context/CartContext";
import Payment from "./pages/Payment";
import "./App.css";

const shoes = [
  { id: 1, name: "Nike Air Max", price: 2500 },
  { id: 2, name: "Adidas Ultraboost", price: 3000 },
  { id: 3, name: "Puma Running Shoes", price: 2000 },
  { id: 4, name: "New Balance", price: 3500 },
  { id: 5, name: "Converse Sneakers", price: 1800 },
  { id: 6, name: "Reebok Classic", price: 2200 }
];

function Home() {
  const { cart, addToCart, removeFromCart, total } = useCart();

  return (
    <div className="container">
      <h1>Shoe Store</h1>
      <p className="subtitle">Find Your Perfect Shoes</p>

      <div className="main-content">
        <div className="products">
          <h2>Available Shoes</h2>

          <div className="shoe-list">
            {shoes.map((shoe) => (
              <div className="shoe-card" key={shoe.id}>
                <div className="shoe-icon">👟</div>
                <h3>{shoe.name}</h3>
                <p>₹{shoe.price}</p>
                <button onClick={() => addToCart(shoe)}>
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="cart">
          <h2>Shopping Cart</h2>

          {cart.length === 0 ? (
            <p className="empty">Your cart is empty</p>
          ) : (
            <>
              {cart.map((item) => (
                <div className="cart-item" key={item.id}>
                  <div>
                    <h3>{item.name}</h3>
                    <p>₹{item.price} × {item.quantity}</p>
                    <p>Subtotal: ₹{item.price * item.quantity}</p>
                  </div>

                  <button
                    className="remove-btn"
                    onClick={() => removeFromCart(item.id)}
                  >
                    Remove
                  </button>
                </div>
              ))}

              <h3 className="total">Total: ₹{total}</h3>

              <Link to="/payment" className="payment-btn">
                Proceed to Payment
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/payment" element={<Payment />} />
    </Routes>
  );
}

export default App;
