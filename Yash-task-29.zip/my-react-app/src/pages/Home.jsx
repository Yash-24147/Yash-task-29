
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="home">
      <div className="hero">
        <p className="tagline">WELCOME TO REACT APP</p>

        <h1>Manage Your Work <span>Smarter</span></h1>

        <p className="description">
          A simple and modern platform to explore your dashboard,
          manage your account and get started with ease.
        </p>

        <div className="hero-buttons">
          <Link to="/dashboard" className="primary-btn">
            Explore Dashboard
          </Link>

          <Link to="/signup" className="secondary-btn">
            Get Started
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Home;
