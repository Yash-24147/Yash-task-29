
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";

function Payment() {
  const { cart, total } = useCart();
  const navigate = useNavigate();

  const handlePayment = (e) => {
    e.preventDefault();
    alert("Payment Successful!");
  };

  if (cart.length === 0) {
    return (
      <div className="payment-page">
        <div className="payment-card">
          <h2>Your Cart is Empty</h2>
          <Link to="/" className="back-btn">
            Return to Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="payment-page">
      <div className="payment-card">
        <h1>Payment Details</h1>
        <p className="payment-subtitle">Complete your purchase</p>

        <div className="order-summary">
          <h2>Order Summary</h2>

          {cart.map((item) => (
            <div className="order-item" key={item.id}>
              <span>{item.name} × {item.quantity}</span>
              <span>₹{item.price * item.quantity}</span>
            </div>
          ))}

          <div className="order-total">
            <strong>Total Amount</strong>
            <strong>₹{total}</strong>
          </div>
        </div>

        <h2 className="card-heading">Credit Card Details</h2>

        <form onSubmit={handlePayment}>
          <label>Cardholder Name</label>
          <input
            type="text"
            placeholder="Enter cardholder name"
            required
          />

          <label>Card Number</label>
          <input
            type="text"
            placeholder="1234 5678 9012 3456"
            pattern="[0-9 ]{13,19}"
            maxLength="19"
            required
          />

          <div className="card-inputs">
            <div>
              <label>Expiry Date</label>
              <input
                type="month"
                required
              />
            </div>

            <div>
              <label>CVV</label>
              <input
                type="password"
                placeholder="CVV"
                pattern="[0-9]{3,4}"
                maxLength="4"
                required
              />
            </div>
          </div>

          <button type="submit" className="pay-btn">
            Pay ₹{total}
          </button>
        </form>

        <button
          className="return-btn"
          onClick={() => navigate("/")}
        >
          Return to Shopping
        </button>
      </div>
    </div>
  );
}

export default Payment;
