
import { Link } from "react-router-dom";

function Register() {
  return (
    <div className="form-page">
      <div className="form-card">
        <h1>Create Account</h1>
        <p>Register to get started</p>

        <form>
          <label>Full Name</label>
          <input type="text" placeholder="Enter your name" required />

          <label>Email Address</label>
          <input type="email" placeholder="Enter your email" required />

          <label>Password</label>
          <input type="password" placeholder="Create a password" required />

          <button type="submit">Register</button>
        </form>

        <p className="form-footer">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
