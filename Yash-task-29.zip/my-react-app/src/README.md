
Shoe Store with Payment React App

About

This is a React application for an online shoe store with shopping cart and payment functionality. It uses Context API to manage cart data across different components and pages.

Technologies Used

React
JavaScript
JSX
CSS
React Hooks
Context API
React Router DOM

Features

Displays different shoes with their names and prices
Allows users to add shoes to the shopping cart
Increases quantity when the same shoe is added again
Allows users to remove shoes from the cart
Calculates the total price of cart items
Uses Context API to manage shopping cart state
Provides a Proceed to Payment button
Displays cart items on the payment page
Allows users to return to shopping
Includes a credit card payment form
Provides responsive user interface

How to Run

Create a React project using Vite
Install React Router DOM
Run npm install
Create CartContext.jsx inside the context folder
Create Payment.jsx inside the pages folder
Add the given code in App.jsx
Add styling in App.css
Open the terminal in the project folder
Run npm run dev
Open the local URL in your browser

Author

Yash
